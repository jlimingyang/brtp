<!doctype html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>口吐真言投票系统</title>

    <link rel="stylesheet" type="text/css" href="css/styles.css">

</head>
<body>


<div class="wrapper">

    <div class="container">
        <h1>口吐真言投票系统</h1>
        <span style="color:red">
                    <?php if(count($errors)>0): ?>
                <div class="">
                      <?php if(is_object($errors)): ?>
                        <?php foreach($errors->all() as $error): ?>
                            <p><?php echo e($error); ?></p>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <p><?php echo e($errors); ?></p>
                    <?php endif; ?>
                          </div>
            <?php endif; ?>
            <?php if(!empty(session('msg'))): ?>
                <?php echo e(session('msg')); ?>

            <?php endif; ?></span>
        <form class="form" action="<?php echo e(url('login')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="text" name="username" placeholder="账号">
            <input type="password" name="userpass" placeholder="密码"><br>
            <button type="submit"><strong>登陆</strong></button><br><br>
            <a href="<?php echo e(url('regist')); ?>"><strong>内部注册通道</strong></a>
        </form>
    </div>

    <ul class="bg-bubbles">
        <li></li>
        <li></li>
    </ul>

</div>



</body>
</html>