<!DOCTYPE html>
<html>
<head>
    <title></title>
    <meta charset="UTF-8">
    <meta name="description" content="Creating Modal Window with Twitter Bootstrap">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-responsive.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(asset('js/jquery2.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery2.sorted.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/ckform.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common.js')); ?>"></script>

    <style type="text/css">
        body {
            padding-bottom: 40px;
            background-color:#e9e7ef;
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }


    </style>
</head>
<body>
<br><br>
<span style="color:red">
                    <?php if(count($errors)>0): ?>
        <div class="">
                      <?php if(is_object($errors)): ?>
                <?php foreach($errors->all() as $error): ?>
                    <p><?php echo e($error); ?></p>
                <?php endforeach; ?>
            <?php else: ?>
                <p><?php echo e($errors); ?></p>
            <?php endif; ?>
                          </div>
    <?php endif; ?>
    <?php if(!empty(session('msg'))): ?>
        <?php echo e(session('msg')); ?>

    <?php endif; ?></span>
<form class="form-inline definewidth m20" action="<?php echo e(url('addChoose')); ?>" method="POST">
    <font color="#33ccff"><strong>选项名：</strong></font>
    <?php echo e(csrf_field()); ?>

    <input type="text" name="choosename" id="menuname"class="abc input-default" placeholder="" value="">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">添加选项</button>
</form>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>选项名</th>
        <th>创建时间</th>
        <th>删除选项</th>
    </tr>
    </thead>
    <?php foreach($data as $k=>$v): ?>
    <tr>
        <td><?php echo e($v->choosename); ?></td>
        <td><?php echo e($v->c_time); ?></td>
        <td><a href="<?php echo e(url('delChoose')); ?>?id=<?php echo e($v->id); ?>">删除</a></td>
    </tr>
<?php endforeach; ?>

</table>

</body>
</html>
<script src="<?php echo e(asset('js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-tooltip.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap-popover.js')); ?>"></script>
<script>
    $(function ()
    { $("#xiangqing").popover();
    });
</script>
