<!DOCTYPE html>
<html>
    <head>
        <title>Laravel</title>

        

        <style>
            html, body {
                height: 100%;
            }

            body {
                margin: 0;
                padding: 0;
                width: 100%;
                display: table;
                font-weight: 100;
                font-family: 'Lato';
            }

            .container {
                text-align: center;
                display: table-cell;
                vertical-align: middle;
            }

            .content {
                text-align: center;
                display: inline-block;
            }

            .title {
                font-size: 96px;
            }
        </style>
    </head>
    <body>
    <p>123</p>
    <div id="landing" style="display:none;">
        <div class="inside">
            <br/>
            <center>欢迎登录网上电子投票系统</center>
            <form action="" method="get">
                <table>
                    <tr><td>用户名：</td><td><input type="text" name="username"/></td></tr>
                    <tr><td>密 码:</td><td><input type="password" name="password"/></td></tr>
                    <tr><td></td><td><input type="button" value="登录"/>
                            <input type="reset"/>
                            <input type="button" value="取消" onclick="exitDiv('landing');"></td></tr>
                </table>
            </form>
        </div>
    </div>
    <div id="register" style="display:none;">
        <div class="inside">
            <br/>
            <center>欢迎注册网上电子投票系统</center>
            <form action="" method="get">
                <table>
                    <tr><td>用户名：</td><td><input type="text" name="username"/></td></tr>
                    <tr><td>密 码:</td><td><input type="password" name="password"/></td></tr>
                    <tr><td>再次输入密码:</td><td><input type="password" name="password2"/></td></tr>
                    <tr><td></td><td><input type="button" value="注册"/>
                            <input type="reset"/>
                            <input type="button" value="取消" onclick="exitDiv('register');"></td></tr>
                </table>
            </form>
        </div>
    </div>
    </body>
</html>
